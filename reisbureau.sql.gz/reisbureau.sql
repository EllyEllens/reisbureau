-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 05 mrt 2024 om 20:00
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reisbureau`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `boekingen`
--

CREATE TABLE `boekingen` (
  `Boeking_ID` int(10) NOT NULL,
  `Klant_ID` int(10) NOT NULL,
  `Plaats_ID` int(10) NOT NULL,
  `Hotel_ID` int(10) NOT NULL,
  `Evenement_ID` int(10) NOT NULL,
  `Vlucht_ID` int(10) NOT NULL,
  `Vertrek_Datum` date NOT NULL,
  `Terugkeer_Datum` date NOT NULL,
  `Totale_Prijs` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `boekingen`
--

INSERT INTO `boekingen` (`Boeking_ID`, `Klant_ID`, `Plaats_ID`, `Hotel_ID`, `Evenement_ID`, `Vlucht_ID`, `Vertrek_Datum`, `Terugkeer_Datum`, `Totale_Prijs`) VALUES
(12301, 20120, 1101, 1111, 10011, 1001, '2024-04-15', '2024-03-25', 700),
(12302, 20121, 2202, 2222, 10022, 1002, '2024-05-20', '2024-05-30', 560),
(12303, 20122, 3303, 3333, 10033, 1003, '2024-06-10', '2024-06-20', 840),
(12304, 20123, 4404, 4444, 10044, 1004, '2024-07-05', '2024-07-15', 600),
(12305, 20124, 5505, 5555, 10055, 1005, '2024-08-18', '2024-08-28', 760);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `excursies_evenementen`
--

CREATE TABLE `excursies_evenementen` (
  `Evenment_ID` int(10) NOT NULL,
  `Plaats_ID` int(10) NOT NULL,
  `Evenement_Type` varchar(25) NOT NULL,
  `Omschrijving` text NOT NULL,
  `Evenement_Data` date NOT NULL,
  `Prijs` decimal(10,0) NOT NULL,
  `Categorie` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `excursies_evenementen`
--

INSERT INTO `excursies_evenementen` (`Evenment_ID`, `Plaats_ID`, `Evenement_Type`, `Omschrijving`, `Evenement_Data`, `Prijs`, `Categorie`) VALUES
(10011, 3303, 'Natuurwandeling', 'Verken de adembenemende uitzichten van de Grand Canyon tijdens een begeleide wandeling door het nationale park.', '2024-04-20', 75, 'Natuur & Avontuur'),
(10022, 1101, 'Kunst & Cultuur Tour', 'Ontdek de artistieke schatten van Parijs, waaronder musea, galerieën en historische bezienswaardigheden.', '2024-05-15', 150, 'Kunst & Cultuur'),
(10033, 4404, 'Theeceremonie en Tempelbe', 'Ervaar de traditionele Japanse theeceremonie en bezoek enkele van de prachtige tempels in Kyoto.', '2024-08-06', 90, 'Cultuur & Geschieden'),
(10044, 5505, 'Wijnproeverij in de Wijng', 'Geniet van een dag vol heerlijke Zuid-Afrikaanse wijnen te midden van schilderachtige wijngaarden.', '2024-07-12', 100, 'Culinaire Ervaringen'),
(10055, 2202, 'Zonsondergangszeiltocht i', 'Zeil mee op een jacht in de prachtige haven van Sydney en geniet van de zonsondergang over het water.', '2024-08-25', 150, ' Avontuur & Ontspann');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `hotels`
--

CREATE TABLE `hotels` (
  `Hotel_ID` int(10) NOT NULL,
  `Plaats_ID` int(10) NOT NULL,
  `Hotel_Naam` varchar(25) NOT NULL,
  `Adres` varchar(25) NOT NULL,
  `Telefoon` bigint(10) NOT NULL,
  `Prijs_per_Nacht` decimal(20,0) NOT NULL,
  `Hotel_Klasse` enum('toerist','midden','eerste','luxe') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `hotels`
--

INSERT INTO `hotels` (`Hotel_ID`, `Plaats_ID`, `Hotel_Naam`, `Adres`, `Telefoon`, `Prijs_per_Nacht`, `Hotel_Klasse`) VALUES
(1111, 3, 'The Peninsula Shanghai', '32 Zhongshan Dong Yi Road', 862123272888, 4500, 'luxe'),
(2222, 1, 'Hotel Plaza Athénée', '25 Avenue Montaigne, 7500', 33153676665, 1150, 'eerste'),
(3333, 5, 'The Oberoi Amarvilas', 'Taj East Gate Rd, Paktola', 915622231515, 3000, 'midden'),
(4444, 2, 'Hotel Danieli', 'Riva degli Schiavoni, 419', 390415226480, 450, 'toerist'),
(5555, 4, 'Belmond Hotel Monasterio', 'Calle Palacio 140, Cusco,', 5184604000, 750, 'midden');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klanten`
--

CREATE TABLE `klanten` (
  `Klant_ID` int(10) NOT NULL,
  `Naam` varchar(25) NOT NULL,
  `Adres` varchar(25) NOT NULL,
  `Telefoon` bigint(10) NOT NULL,
  `Paspoort_Nummer` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `klanten`
--

INSERT INTO `klanten` (`Klant_ID`, `Naam`, `Adres`, `Telefoon`, `Paspoort_Nummer`) VALUES
(20120, 'Emily Johnson', '123 Maple Street, Apt 4B,', 234567, 'AB123456'),
(20121, 'Alexander Rodriguez', '456 Oak Avenue, Unit 7, S', 2345678, 'CD789012'),
(20122, 'Maya Patel', '789 Rose Lane, Suite 12, ', 9876543210, 'EF345678'),
(20123, 'Adrian Thompson', '101 Pine Grove, Apartment', 2071234567, 'GH901234'),
(20124, 'Olivia Chen', '234 Lotus Lane, Unit 8, B', 1087654321, 'IJ567890');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `plaatsen`
--

CREATE TABLE `plaatsen` (
  `Plaats_ID` int(10) NOT NULL,
  `Plaats_Naam` varchar(25) NOT NULL,
  `Land` varchar(25) NOT NULL,
  `Omschrijving` text NOT NULL,
  `Gem_Temp_Maand` decimal(15,0) NOT NULL,
  `Gem_Aantal_Uren_Zon` decimal(15,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `plaatsen`
--

INSERT INTO `plaatsen` (`Plaats_ID`, `Plaats_Naam`, `Land`, `Omschrijving`, `Gem_Temp_Maand`, `Gem_Aantal_Uren_Zon`) VALUES
(1101, 'Eiffeltoren', 'Frankrijk', 'Iconische toren in Parijs, gebouwd voor de Wereldtentoonstelling van 1889, biedt adembenemend uitzicht.\r\n', 7, 5),
(2202, 'Het Colosseum', 'Italië', ' Indrukwekkend amfitheater in Rome, gebouwd in 80 na Christus, bekend om gladiatorengevechten.\r\n', 11, 6),
(3303, 'Grote Muur van China', 'China', 'Historisch verdedigingswerk, kilometers lang, gebouwd om het Chinese rijk te beschermen.\r\n', 7, 8),
(4404, 'Machu Picchu', 'Peru', 'Oude Inca-stad hoog in de Andes, gebouwd in de 15e eeuw, spectaculaire archeologische vindplaats.\r\n', 17, 5),
(5505, 'Taj Mahal', 'India', 'Wit marmeren mausoleum in Agra, gebouwd in de 17e eeuw ter nagedachtenis aan een overleden vrouw, bekend om romantische architectuur.', 23, 8);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vluchten`
--

CREATE TABLE `vluchten` (
  `Vlucht_ID` int(10) NOT NULL,
  `Luchtvaartmaatschappij` varchar(25) NOT NULL,
  `Vlucht_Nummer` varchar(20) NOT NULL,
  `Vlucht_Datum` date NOT NULL,
  `Vertrek_Tijd` time NOT NULL,
  `Aankomst_Tijd` time NOT NULL,
  `Prijs` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `vluchten`
--

INSERT INTO `vluchten` (`Vlucht_ID`, `Luchtvaartmaatschappij`, `Vlucht_Nummer`, `Vlucht_Datum`, `Vertrek_Tijd`, `Aankomst_Tijd`, `Prijs`) VALUES
(1001, 'AirWings', 'AW123', '2024-04-15', '14:30:00', '18:00:00', 350),
(1002, 'SkyExpress', 'SE456', '2024-05-20', '09:45:00', '13:30:00', 280),
(1003, 'AeroJet', 'AJ789', '2024-06-10', '18:15:00', '22:45:00', 420),
(1004, 'GlobalAirways', 'GA101', '2024-07-05', '11:00:00', '15:30:00', 300),
(1005, 'PacificSkies', ' PS234', '2024-08-18', '16:20:00', '20:45:00', 380);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `boekingen`
--
ALTER TABLE `boekingen`
  ADD PRIMARY KEY (`Boeking_ID`);

--
-- Indexen voor tabel `excursies_evenementen`
--
ALTER TABLE `excursies_evenementen`
  ADD PRIMARY KEY (`Evenment_ID`);

--
-- Indexen voor tabel `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`Hotel_ID`);

--
-- Indexen voor tabel `klanten`
--
ALTER TABLE `klanten`
  ADD PRIMARY KEY (`Klant_ID`);

--
-- Indexen voor tabel `plaatsen`
--
ALTER TABLE `plaatsen`
  ADD PRIMARY KEY (`Plaats_ID`);

--
-- Indexen voor tabel `vluchten`
--
ALTER TABLE `vluchten`
  ADD PRIMARY KEY (`Vlucht_ID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `boekingen`
--
ALTER TABLE `boekingen`
  MODIFY `Boeking_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12306;

--
-- AUTO_INCREMENT voor een tabel `excursies_evenementen`
--
ALTER TABLE `excursies_evenementen`
  MODIFY `Evenment_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10056;

--
-- AUTO_INCREMENT voor een tabel `klanten`
--
ALTER TABLE `klanten`
  MODIFY `Klant_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20134;

--
-- AUTO_INCREMENT voor een tabel `vluchten`
--
ALTER TABLE `vluchten`
  MODIFY `Vlucht_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1006;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
